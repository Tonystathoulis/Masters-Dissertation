
App Description:
------------
This application is an interactive AutoML tool built with Reflex. It allows users to upload datasets, configure machine learning tasks, train multiple models and visualize results in a user-friendly web interface.

Features:
---------
- Upload your CSV dataset
- Preview and explore data
- Select target column and task type (classification/regression)
- Train and compare multiple ML models automatically
- Visualize model performance and feature importance

How to Run:
-----------
1. Make sure Python 3.10+ is installed.
2. Double-click the `install_requirements.bat` file to install all necessary Python packages.
3. Open a terminal in this folder and run:  reflex run
4. Open your browser and go to the address shown in the terminal.

How to Test:
------------
- Use the app to upload your own CSV file and follow the on-screen steps.
- The app will automatically train and evaluate several models, then display results and plots.
