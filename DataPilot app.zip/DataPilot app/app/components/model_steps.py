import reflex as rx
from app.states.main_state import AppState

#TRAINING STEP MODEL CONFIG REVIEW AND ENTRY POINT OF EXECUTION
def train_step() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h2(
                "Model Training", class_name="text-2xl font-bold text-gray-900 mb-2"
            ),
            rx.el.p(
                "Review configuration and train automated machine learning models.",
                class_name="text-gray-600 mb-8",
            ),

            #CONFIG SUMMARY - FINAL SANITY CHECK BEFORE TRAINING EXECUTION
            rx.el.div(
                rx.el.h3(
                    "Configuration Summary",
                    class_name="text-lg font-semibold text-gray-800 mb-4",
                ),

                #DISPLAY CORE PIPELINE PARAMETERS (TARGET, TASK, SPLIT, DATA SIZE)
                rx.el.div(
                    rx.el.div(
                        rx.el.p(
                            "Target Variable",
                            class_name="text-sm text-gray-500 font-medium",
                        ),
                        rx.el.p(
                            AppState.target_column,
                            class_name="text-base font-semibold text-gray-900",
                        ),
                    ),
                    rx.el.div(
                        rx.el.p(
                            "Task Type",
                            class_name="text-sm text-gray-500 font-medium",
                        ),
                        rx.el.p(
                            AppState.task_type,
                            class_name="text-base font-semibold text-gray-900",
                        ),
                    ),
                    rx.el.div(
                        rx.el.p(
                            "Train / Test Split",
                            class_name="text-sm text-gray-500 font-medium",
                        ),
                        rx.el.p(
                            f"{100 - AppState.test_size}% / {AppState.test_size}%",
                            class_name="text-base font-semibold text-gray-900",
                        ),
                    ),
                    rx.el.div(
                        rx.el.p(
                            "Rows",
                            class_name="text-sm text-gray-500 font-medium",
                        ),
                        rx.el.p(
                            AppState.dataset_shape,
                            class_name="text-base font-semibold text-gray-900",
                        ),
                    ),

                    #GRID LAYOUT FOR COMPARABILITY ACROSS CONFIG DIMENSIONS
                    class_name="grid grid-cols-2 md:grid-cols-4 gap-6 p-6 bg-gray-50 rounded-xl border border-gray-200 mb-8",
                ),
            ),

            #TRAINING ENTRY STATE - GATE BEFORE MODEL EXECUTION STARTS
            rx.el.div(
                rx.cond(
                    #ONLY SHOW "READY STATE" IF TRAINING HAS NOT STARTED YET
                    (AppState.training_progress == 0) & (~AppState.is_training),

                    #IDLE STATE - USER CAN INITIATE TRAINING PIPELINE
                    rx.el.div(
                        rx.icon("bot", class_name="w-12 h-12 text-gray-700 mb-4"),
                        rx.el.h3(
                            "Ready to Train",
                            class_name="text-xl font-semibold text-gray-900 mb-2",
                        ),
                        rx.el.p(
                            "5 different models will be trained and their performance will be compared automatically.",
                            class_name="text-gray-600 mb-6 max-w-md mx-auto",
                        ),

                        #STARTS BACKEND TRAINING PIPELINE (ASYNC BACKGROUND TASK)
                        rx.el.button(
                            rx.icon("play", class_name="w-5 h-5 mr-2"),
                            "Start Training Pipeline",
                            on_click=AppState.train_models,
                            class_name="flex items-center justify-center px-8 py-3.5 bg-gray-900 text-white rounded-xl hover:bg-black font-bold shadow-md transition-all transform hover:scale-105 mx-auto",
                        ),

                        class_name="text-center p-12 bg-white border-2 border-dashed border-gray-300 rounded-2xl",
                    ),

                    #ACTIVE STATE - TRAINING PROGRESS VISUALIZATION + STATUS FEEDBACK
                    rx.el.div(
                        rx.el.div(
                            rx.el.span(
                                AppState.training_status_msg,
                                class_name="text-sm font-medium text-gray-700",
                            ),
                            rx.el.span(
                                f"{AppState.training_progress}%",
                                class_name="text-sm font-bold text-gray-900",
                            ),
                            class_name="flex justify-between items-center mb-2",
                        ),

                        #PROGRESS BAR REFLECTS BACKEND TRAINING STATE IN REAL TIME
                        rx.el.div(
                            rx.el.div(
                                class_name="h-3 bg-gray-900 rounded-full transition-all duration-500 ease-out",
                                style={"width": f"{AppState.training_progress}%"},
                            ),
                            class_name="w-full h-3 bg-gray-100 rounded-full overflow-hidden shadow-inner mb-6",
                        ),

                        #FINAL STATE - MODEL SELECTION + NAVIGATION TO RESULTS
                        rx.cond(
                            AppState.training_progress == 100,

                            rx.el.div(
                                rx.icon(
                                    "circle_check",
                                    class_name="w-16 h-16 text-emerald-500 mb-4 mx-auto",
                                ),
                                rx.el.h3(
                                    "Training Complete!",
                                    class_name="text-xl font-bold text-gray-900 mb-2",
                                ),
                                rx.el.p(
                                    f"Best Model: {AppState.best_model_name} ({AppState.best_model_score})",
                                    class_name="text-gray-600 mb-6",
                                ),

                                #FORWARD NAVIGATION INTO RESULTS ANALYSIS PHASE
                                rx.el.button(
                                    "View Full Results",
                                    rx.icon("arrow-right", class_name="w-4 h-4 ml-2"),
                                    on_click=AppState.next_step,
                                    class_name="flex items-center justify-center px-6 py-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 font-semibold shadow-sm transition-colors mx-auto",
                                ),

                                class_name="text-center animate-fade-in",
                            ),

                            #LOADING STATE - MODEL TRAINING STILL IN PROGRESS
                            rx.el.div(
                                rx.icon(
                                    "loader",
                                    class_name="w-10 h-10 text-gray-700 animate-spin mx-auto mb-4",
                                ),
                                rx.el.p(
                                    "Please wait while models are being trained...",
                                    class_name="text-gray-500 text-center",
                                ),
                                class_name="py-8",
                            ),
                        ),

                        class_name="p-8 bg-white border border-gray-200 rounded-xl shadow-sm",
                    ),
                )
            ),

            class_name="bg-white p-8 rounded-2xl shadow-sm border border-gray-100",
        )
    )

#MODEL COMPARISON CHART: VISUAL PERFORMANCE RANKING ACROSS ALGORITHMS
def model_comp_chart() -> rx.Component:
    return rx.el.div(
        rx.el.h3(
            "Performance Comparison",
            class_name="text-lg font-semibold text-gray-800 mb-4",
        ),

        #BAR CHART: SHOWS RELATIVE MODEL PERFORMANCE USING PRIMARY METRIC
        rx.el.div(
            rx.recharts.bar_chart(
                rx.recharts.cartesian_grid(
                    horizontal=True,
                    vertical=False,
                    stroke_dasharray="3 3",),

                #X-AXIS: MODEL NAMES (ROTATED FOR READABILITY WITH LONG LABELS)
                rx.recharts.x_axis(
                    data_key="name",
                    axis_line=False,
                    tick_line=False,
                    custom_attrs={"fontSize": "12px", "angle": -30, "textAnchor": "end"},),

                #Y-AXIS: PERFORMANCE SCALE (METRIC-DEPENDENT)
                rx.recharts.y_axis(
                    axis_line=False,
                    tick_line=False,
                    custom_attrs={"fontSize": "12px"},),

                #PRIMARY METRIC BAR (USED FOR MODEL RANKING DECISION)
                rx.recharts.bar(
                    data_key="primary_metric",
                    fill="#1f2937",
                    radius=[4, 4, 0, 0],),

                data=AppState.model_results,
                width="100%",
                height=300,
                margin={"top": 20, "right": 30, "left": 20, "bottom": 50},
            ),
            class_name="w-full h-[320px]",
        ),

        class_name="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm",
    )

#MODEL ROW: SINGLE ENTRY IN PERFORMANCE LEADERBOARD
def model_row(model: dict[str, str]) -> rx.Component:
    #HIGHLIGHT BEST MODEL FOR VISUAL PRIORITIZATION IN TABLE
    is_best = model["name"] == AppState.best_model_name

    return rx.el.tr(
        rx.el.td(
            model["name"],
            class_name="px-4 py-3 text-sm font-medium text-gray-900",
        ),
        rx.el.td(
            model["primary_metric"],
            class_name="px-4 py-3 text-sm text-gray-700",
        ),
        rx.el.td(
            model["secondary_metric"],
            class_name="px-4 py-3 text-sm text-gray-700",
        ),

        #VISUAL EMPHASIS ON BEST PERFORMER FOR QUICK COMPARISON
        class_name=rx.cond(is_best, "bg-gray-100", "hover:bg-gray-50"),
    )

#PLOT CARD: STANDARDIZED WRAPPER FOR ALL MODEL VISUAL OUTPUTS
def plot_card(plot_data: dict[str, str]) -> rx.Component:
    return rx.el.div(
        rx.el.h4(
            plot_data["name"],
            class_name="text-md font-semibold text-gray-800 mb-2 text-center",
        ),

        #IMAGE-BASED VISUALIZATION OUTPUT (GENERATED FROM BACKEND PLOTS)
        rx.image(
            src=plot_data["plot"],
            class_name="w-full h-auto rounded-lg border border-gray-100",
        ),

        class_name="bg-gray-50 p-4 rounded-xl border border-gray-200 shadow-sm",
    )

#DATA VALIDITY WARNING - FLAGGED WHEN MODEL PERFORMANCE SUGGESTS LEAKAGE OR OVERFITTING
def warn_bn() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.icon(
                "triangle_alert",
                class_name="h-5 w-5 text-amber-600 mr-3 shrink-0",
            ),

            rx.el.div(
                rx.el.p(
                    "Check data validity",
                    class_name="text-sm font-bold text-amber-900",
                ),
                rx.el.p(
                    "Multiple models achieved perfect scores, which may indicate data leakage, overfitting, or invalid data.",
                    class_name="text-xs font-medium text-amber-800 mt-0.5",
                ),
                class_name="flex flex-col",
            ),
            class_name="flex items-start",
        ),

        #HIGH-PRIORITY WARNING STYLE TO VISUALLY INTERRUPT NORMAL FLOW
        class_name="w-full bg-amber-50 border border-amber-300 rounded-xl p-4 mb-6 shadow-sm",
    )


#RESULTS STEP - FINAL PIPELINE STAGE (ANALYSIS + INTERPRETATION + EXPORT CONTEXT)
def results_step() -> rx.Component:
    return rx.el.div(

        #CONDITIONAL DATA QUALITY ALERT (ONLY SHOWN WHEN HEURISTIC DETECTS ISSUE)
        rx.cond(AppState.show_data_validity_warning, warn_bn(), rx.fragment()),

        #BEST MODEL SUMMARY: HIGH-LEVEL PERFORMANCE SNAPSHOT
        rx.el.div(
            rx.el.div(
                rx.el.div(
                    rx.icon("trophy", class_name="w-12 h-12 text-amber-500 mb-4"),

                    rx.el.h2(
                        "Best Performing Model",
                        class_name="text-sm font-semibold text-gray-600 uppercase tracking-wider",
                    ),

                    rx.el.p(
                        AppState.best_model_name,
                        class_name="text-3xl font-bold text-gray-900 mt-1",
                    ),

                    #TASK TYPE CONTEXTUAL LABEL FOR INTERPRETING SCORE MEANING
                    rx.el.div(
                        AppState.task_type,
                        class_name="mt-4 bg-gray-200 text-gray-800 px-3 py-1 rounded-full text-xs font-bold w-fit",
                    ),

                    class_name="flex-1",
                ),

                rx.el.div(
                    rx.el.p(
                        "Primary Score",
                        class_name="text-sm font-medium text-gray-500",
                    ),
                    rx.el.p(
                        AppState.best_model_score,
                        class_name="text-4xl font-black text-gray-900",
                    ),
                    class_name="text-right",
                ),

                class_name="flex items-center justify-between",
            ),

            class_name="bg-white p-8 rounded-3xl border-2 border-gray-200 shadow-lg mb-8",
        ),

        #MODEL PERFORMANCE ANALYSIS BLOCK (VISUAL + TABULAR COMPARISON)
        rx.el.div(
            model_comp_chart(),

            rx.el.div(
                rx.el.h3(
                    "Model Comparison Leaderboard",
                    class_name="text-lg font-semibold text-gray-800 mb-4",
                ),

                rx.el.div(
                    rx.el.table(
                        rx.el.thead(
                            rx.el.tr(
                                rx.el.th(
                                    "Model Name",
                                    class_name="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase",
                                ),

                                #METRIC LABELS ADAPT BASED ON PROBLEM TYPE
                                rx.el.th(
                                    rx.cond(
                                        AppState.task_type == "Classification",
                                        "Accuracy",
                                        "R2 Score",
                                    ),
                                    class_name="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase",
                                ),
                                rx.el.th(
                                    rx.cond(
                                        AppState.task_type == "Classification",
                                        "F1 Score",
                                        "RMSE",
                                    ),
                                    class_name="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase",
                                ),

                                class_name="border-b border-gray-100",
                            )
                        ),

                        #DYNAMIC ROW GENERATION FROM TRAINING RESULTS STATE
                        rx.el.tbody(rx.foreach(AppState.model_results, model_row)),
                        class_name="w-full table-auto",
                    ),
                    class_name="overflow-hidden border border-gray-100 rounded-xl",
                ),

                class_name="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm",
            ),

            class_name="flex flex-col gap-8 w-full mb-8",
        ),

        #FEATURE IMPORTANCE: ONLY AVAILABLE FOR INTERPRETABLE MODELS
        rx.el.div(
            rx.el.h3(
                "Feature Importance",
                class_name="text-lg font-semibold text-gray-800 mb-4",
            ),

            rx.cond(
                AppState.feature_importance_plot != "",

                #MODEL SUPPORTS FEATURE IMPORTANCE VISUALIZATION
                rx.image(
                    src=AppState.feature_importance_plot,
                    class_name="w-full max-w-3xl mx-auto h-auto rounded-lg shadow-sm border border-gray-100",
                ),

                #FALLBACK WHEN MODEL IS NON-INTERPRETABLE (E.G. KNN)
                rx.el.div(
                    rx.icon("info", class_name="w-8 h-8 text-gray-300 mx-auto mb-2"),
                    rx.el.p(
                        "Feature importance is not supported for the current best model type (e.g., K-NN).",
                        class_name="text-sm text-gray-400 text-center",
                    ),
                    class_name="py-8 px-4 bg-gray-50 rounded-xl",
                ),
            ),

            class_name="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm w-full mb-8",
        ),

        #TASK-SPECIFIC VISUALIZATION BRANCHING (CLASSIFICATION VS REGRESSION)
        rx.cond(
            AppState.task_type == "Classification",

            #CLASSIFICATION - ERROR ANALYSIS VIA CONFUSION MATRICES
            rx.el.div(
                rx.el.h3(
                    "Confusion Matrices",
                    class_name="text-lg font-semibold text-gray-800 mb-4",
                ),
                rx.el.div(
                    rx.foreach(AppState.confusion_matrix_plots, plot_card),
                    class_name="grid grid-cols-1 md:grid-cols-2 gap-6",
                ),
                class_name="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm w-full mb-8",
            ),

            #REGRESSION - PREDICTION QUALITY VISUALIZATION
            rx.el.div(
                rx.el.h3(
                    "Predicted vs Actual",
                    class_name="text-lg font-semibold text-gray-800 mb-4",
                ),
                rx.el.div(
                    rx.foreach(AppState.pred_vs_actual_plots, plot_card),
                    class_name="grid grid-cols-1 md:grid-cols-2 gap-6",
                ),
                class_name="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm w-full mb-8",
            ),
        ),

        #CORRELATION HEATMAP
        rx.cond(
            AppState.correlation_heatmap != "",

            rx.el.div(
                rx.el.h3(
                    "Correlation Heatmap",
                    class_name="text-lg font-semibold text-gray-800 mb-1",
                ),
                rx.el.p(
                    "Correlation between numeric features in the dataset",
                    class_name="text-sm text-gray-500 mb-4",
                ),
                rx.image(
                    src=AppState.correlation_heatmap,
                    class_name="w-full max-w-3xl mx-auto h-auto rounded-lg shadow-sm border border-gray-100",
                ),
                class_name="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm w-full mb-8 text-center",
            ),
            None,
        ),

        #PIPELINE RESET ACTION - RETURNS USER TO INITIAL STATE FOR NEW EXPERIMENT
        rx.el.div(
            rx.el.button(
                rx.icon("refresh-cw", class_name="w-4 h-4 mr-2"),
                "Start New Analysis",
                on_click=AppState.start_over,
                class_name="flex items-center justify-center px-8 py-4 bg-gray-900 text-white rounded-2xl font-bold hover:bg-black transition-all shadow-lg mx-auto",
            ),
            class_name="pb-12",
        ),

        class_name="animate-fade-in",
    )