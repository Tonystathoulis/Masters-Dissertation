import reflex as rx
from app.states.main_state import AppState

#UPLOAD COMPONENT ID (USED TO LINK UI AND STATE EVENT HANDLER)
UPLOAD_ID = "csv_upload_zone"

#UPLOAD STEP UI - ENTRY POINT FOR DATA INGESTION
def upload_step() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h2(
                "Upload Dataset", class_name="text-2xl font-bold text-gray-900 mb-2"
            ),
            rx.el.p(
                "Upload a CSV file to begin predictive analytics.",
                class_name="text-gray-600 mb-8",
            ),

            #FILE UPLOAD ZONE (DRAG AND DROP + CLICK)
            rx.upload.root(
                rx.el.div(
                    rx.icon("file-up", class_name="w-12 h-12 text-gray-700 mb-4"),
                    rx.el.p(
                        rx.el.span(
                            "Click to upload", class_name="font-bold text-gray-900"
                        ),
                        " or drag and drop",
                        class_name="text-gray-700 text-lg mb-2",
                    ),
                    rx.el.p(
                        "CSV files only", class_name="text-sm text-gray-500"
                    ),
                    class_name="flex flex-col items-center justify-center p-12 border-2 border-dashed border-gray-300 rounded-2xl bg-gray-50 hover:bg-gray-100 hover:border-gray-400 transition-colors cursor-pointer w-full max-w-2xl mx-auto",
                ),
                id=UPLOAD_ID,
                accept={"text/csv": [".csv"]},
                max_files=1,  #ENFORCE SINGLE DATASET FOR SIMPLIFIED PIPELINE ASSUMPTIONS
            ),

            #DISPLAY SELECTED FILE NAME FOR USER FEEDBACK
            rx.el.div(
                rx.foreach(
                    rx.selected_files(UPLOAD_ID),
                    lambda file: rx.el.div(
                        rx.icon("file-text", class_name="w-5 h-5 text-gray-500 mr-2"),
                        rx.el.span(
                            file, class_name="text-sm font-medium text-gray-700"
                        ),
                        class_name="flex items-center mt-4 p-3 bg-gray-50 rounded-lg border border-gray-200 w-full max-w-md mx-auto",
                    ),
                )
            ),

            #PROGRESSION GATE - ONLY ENABLE CONTINUE WHEN FILE EXISTS
            rx.el.div(
                rx.el.button(
                    rx.cond(
                        rx.selected_files(UPLOAD_ID).length() > 0,

                        #TRIGGER BACKEND INGESTION BEFORE NAVIGATION
                        rx.el.div(
                            rx.icon("arrow-right", class_name="w-4 h-4 mr-2"),
                            "Continue to Preview",
                            on_click=AppState.handle_upload(
                                rx.upload_files(upload_id=UPLOAD_ID)
                            ),
                            class_name="flex items-center justify-center px-6 py-3 bg-gray-900 text-white rounded-xl hover:bg-black font-bold shadow-md transition-all transform hover:scale-105 mx-auto",
                        ),

                        #DISABLED STATE PREVENTS INVALID PIPELINE TRANSITION
                        rx.el.div(
                            "Upload a file to continue",
                            class_name="px-6 py-3 bg-gray-300 text-gray-500 rounded-xl font-bold mx-auto cursor-not-allowed",
                        ),
                    )
                ),
                class_name="mt-8",
            ),

            class_name="bg-white p-8 rounded-2xl shadow-sm border border-gray-100",
        ),

        #FOOTER
        rx.el.p(
            "© 2026 DataPilot.",
            class_name="text-xs text-gray-400 text-center mt-6",
        ),
    )

#TABLE HEADER CELL (REUSED FOR DATA PREVIEW + METADATA TABLES)
def data_tb_header(col: str) -> rx.Component:
    return rx.el.th(
        col,
        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b border-gray-200",
    )

#TABLE CELL (GENERIC VALUE RENDERING)
def data_tb_cell(val: str) -> rx.Component:
    return rx.el.td(
        val,
        class_name="px-4 py-3 whitespace-nowrap text-sm text-gray-700 border-b border-gray-100",
    )

#DATA ROW RENDERING - DYNAMICALLY MAPS OVER CURRENT DATASET COLUMNS
def row_rend(row: dict) -> rx.Component:
    return rx.el.tr(
        rx.foreach(AppState.columns, lambda col: data_tb_cell(row[col])),
        class_name="hover:bg-gray-50 transition-colors",
    )


#COLUMN METADATA ROW (TYPE, COMPLETENESS, CARDINALITY)
def col_inf_row(info: dict) -> rx.Component:
    return rx.el.tr(
        rx.el.td(
            info["name"],
            class_name="px-4 py-3 text-sm font-medium text-gray-900 border-b border-gray-100",),
        rx.el.td(
            info["dtype"],
            class_name="px-4 py-3 text-sm text-gray-600 border-b border-gray-100",),
        rx.el.td(
            info["non_null"],
            class_name="px-4 py-3 text-sm text-gray-600 border-b border-gray-100",),
        rx.el.td(
            info["unique"],
            class_name="px-4 py-3 text-sm text-gray-600 border-b border-gray-100",),
        class_name="hover:bg-gray-50 transition-colors",
    )


#NUMERIC SUMMARY ROW (PRECOMPUTED STATISTICS FROM BACKEND)
def num_stats_row(stat: dict) -> rx.Component:
    return rx.el.tr(
        rx.el.td(
            stat["name"],
            class_name="px-4 py-3 text-sm font-medium text-gray-900 border-b border-gray-100",),
        rx.el.td(
            stat["mean"],
            class_name="px-4 py-3 text-sm text-gray-600 border-b border-gray-100",),
        rx.el.td(
            stat["std"],
            class_name="px-4 py-3 text-sm text-gray-600 border-b border-gray-100",),
        rx.el.td(
            stat["min"],
            class_name="px-4 py-3 text-sm text-gray-600 border-b border-gray-100",),
        rx.el.td(
            stat["max"],
            class_name="px-4 py-3 text-sm text-gray-600 border-b border-gray-100",),
        class_name="hover:bg-gray-50 transition-colors",
    )

#PREVIEW STEP - VALIDATION INGESTION + DATA UNDERSTANDING BEFORE MODELING
def preview_step() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h2(
                "Dataset Preview", class_name="text-2xl font-bold text-gray-900 mb-2"
            ),

            #DISPLAY CORE DATASET METADATA (USED FOR QUICK SANITY CHECK)
            rx.el.div(
                rx.el.span("File: ", class_name="text-gray-500 font-medium"),
                rx.el.span(
                    AppState.filename, class_name="text-gray-900 font-semibold mr-6"
                ),
                rx.el.span("Shape: ", class_name="text-gray-500 font-medium"),
                rx.el.span(
                    AppState.dataset_shape, class_name="text-gray-900 font-semibold"
                ),
                class_name="mb-8 text-sm",
            ),
 #PREVIEW TABLE          
rx.el.div(
    rx.el.h3(
        "First 10 Rows",
        class_name="text-lg font-semibold text-gray-800 mb-4",
    ),
    rx.el.div(
        rx.el.table(
            rx.el.thead(
                rx.el.tr(rx.foreach(AppState.columns, data_tb_header))
            ),
            #ROW RENDERING DRIVEN BY STATE → ENSURES UI AUTO-UPDATES ON DATA CHANGE
            rx.el.tbody(rx.foreach(AppState.raw_data, row_rend)),
            class_name="min-w-full",
        ),
        class_name="overflow-x-auto border border-gray-200 rounded-xl mb-8 shadow-sm",
    ),
),

#COLUMN METADATA - FOR FEATURE UNDERSTANDING + TARGET SELECTION DECISIONS
rx.el.div(
    rx.el.h3(
        "Column Information",
        class_name="text-lg font-semibold text-gray-800 mb-4",
    ),
    rx.el.div(
        rx.el.table(
            rx.el.thead(
                rx.el.tr(
                    rx.el.th(
                        "Column Name",
                        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase border-b border-gray-200",),
                    rx.el.th(
                        "Data Type",
                        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase border-b border-gray-200",),
                    rx.el.th(
                        "Non-Null Count",
                        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase border-b border-gray-200",),
                    rx.el.th(
                        "Unique Values",
                        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase border-b border-gray-200",),
                )
            ),
            #PRECOMPUTED BACKEND METADATA TO AVOID HEAVY COMPUTATION IN UI LAYER
            rx.el.tbody(rx.foreach(AppState.column_info, col_inf_row)),
            class_name="min-w-full",
        ),
        class_name="overflow-x-auto border border-gray-200 rounded-xl mb-8 shadow-sm",
    ),
),

#NUMERIC SUMMARY - SUPPORTS QUICK DISTRIBUTION AWARENESS BEFORE MODELING
rx.el.div(
    rx.el.h3(
        "Numeric Statistics",
        class_name="text-lg font-semibold text-gray-800 mb-4",
    ),
    rx.el.div(
        rx.el.table(
            rx.el.thead(
                rx.el.tr(
                    rx.el.th(
                        "Column",
                        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase border-b border-gray-200",),
                    rx.el.th(
                        "Mean",
                        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase border-b border-gray-200",),
                    rx.el.th(
                        "Std Dev",
                        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase border-b border-gray-200",),
                    rx.el.th(
                        "Min",
                        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase border-b border-gray-200",),
                    rx.el.th(
                        "Max",
                        class_name="px-4 py-3 bg-gray-50 text-left text-xs font-semibold text-gray-600 uppercase border-b border-gray-200",),
                )
            ),
            #ONLY NUMERIC COLUMNS INCLUDED (FILTERED DURING PREPROCESSING)
            rx.el.tbody(rx.foreach(AppState.numeric_stats, num_stats_row)),
            class_name="min-w-full",
        ),
        class_name="overflow-x-auto border border-gray-200 rounded-xl shadow-sm",
    ),
),

class_name="bg-white p-8 rounded-2xl shadow-sm border border-gray-100",)
)

#TARGET CONFIGURATION STEP - DEFINES PREDICTION GOAL + TRAINING BEHAVIOR
def target_step() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h2(
                "Configure Target & Training",
                class_name="text-2xl font-bold text-gray-900 mb-2",
            ),
            rx.el.p(
                "Select the target variable you want to predict.",
                class_name="text-gray-600 mb-8",
            ),

            #TARGET COLUMN SELECTION (DRIVES ENTIRE PIPELINE LOGIC)
            rx.el.div(
                rx.el.label(
                    "Target Variable",
                    class_name="block text-sm font-semibold text-gray-700 mb-2",
                ),
                rx.el.div(
                    rx.icon(
                        "crosshair",
                        class_name="absolute left-3 top-3 h-5 w-5 text-gray-400",
                    ),
                    rx.el.select(
                        rx.el.option("Select a column...", value=""),
                        rx.foreach(
                            AppState.columns, lambda col: rx.el.option(col, value=col)
                        ),
                        value=AppState.target_column,
                        on_change=AppState.set_target_column,
                        class_name="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent appearance-none cursor-pointer text-gray-700",
                    ),
                    rx.icon(
                        "chevron-down",
                        class_name="absolute right-3 top-3 h-5 w-5 text-gray-400 pointer-events-none",
                    ),
                    class_name="relative w-full max-w-md mb-8",
                ),

                #CONDITIONAL UI - ONLY SHOW INSIGHTS AFTER VALID TARGET SELECTION
                rx.cond(
                    AppState.target_column != "",
                    rx.el.div(
                        rx.el.div(
                            rx.el.div(
                                rx.el.h4(
                                    "Detected Task Type",
                                    class_name="text-sm font-semibold text-gray-500 mb-1",
                                ),

                                #TASK TYPE COMES FROM BACKEND HEURISTIC (NOT USER INPUT)
                                rx.el.div(
                                    AppState.task_type,
                                    class_name=rx.cond(
                                        AppState.task_type == "Classification",
                                        "bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-bold w-fit",
                                        "bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full text-sm font-bold w-fit",
                                    ),
                                ),
                                class_name="mb-6",
                            ),

                            #SURFACE TARGET METADATA TO VALIDATE MODELING ASSUMPTIONS
                            rx.el.div(
                                rx.el.h4(
                                    "Target Column Details",
                                    class_name="text-sm font-semibold text-gray-500 mb-2",
                                ),
                                rx.el.div(
                                    rx.el.p(
                                        rx.el.span(
                                            "Data Type: ",
                                            class_name="font-medium text-gray-600",
                                        ),
                                        AppState.target_stats["dtype"],
                                        class_name="text-sm",
                                    ),
                                    rx.el.p(
                                        rx.el.span(
                                            "Unique Values: ",
                                            class_name="font-medium text-gray-600",
                                        ),
                                        AppState.target_stats["unique"],
                                        class_name="text-sm",
                                    ),
                                    rx.el.p(
                                        rx.el.span(
                                            "Non-Null Count: ",
                                            class_name="font-medium text-gray-600",
                                        ),
                                        AppState.target_stats["non_null"],
                                        class_name="text-sm",
                                    ),
                                    class_name="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-xl border border-gray-200",
                                ),
                            ),
                        ),
                        class_name="p-6 bg-white border border-gray-200 rounded-xl shadow-sm mb-8 animate-fade-in",
                    ),
                ),

                #TRAIN/TEST SPLIT - USER-CONTROLLED GENERALIZATION TRADEOFF
                rx.el.div(
                    rx.el.h3(
                        "Train / Test Split Ratio",
                        class_name="text-lg font-semibold text-gray-800 mb-4",
                    ),
                    rx.el.div(
                        rx.el.input(
                            type="range",
                            min="10",
                            max="90",
                            step="5",
                            key=AppState.test_size.to_string(),
                            default_value=AppState.test_size.to_string(),
                            #THROTTLED TO PREVENT EXCESSIVE STATE UPDATES DURING DRAG
                            on_change=AppState.set_test_size.throttle(100),
                            class_name="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-gray-900 mb-4",
                        ),

                        #REAL-TIME FEEDBACK FOR DATA SPLIT IMPACT
                        rx.el.div(
                            rx.el.div(
                                rx.el.span(
                                    "Training Set", class_name="text-sm text-gray-500"
                                ),
                                rx.el.p(
                                    f"{100 - AppState.test_size}%",
                                    class_name="text-xl font-bold text-gray-900",
                                ),
                            ),
                            rx.el.div(
                                rx.el.span(
                                    "Test Set", class_name="text-sm text-gray-500"
                                ),
                                rx.el.p(
                                    f"{AppState.test_size}%",
                                    class_name="text-xl font-bold text-indigo-700",
                                ),
                            ),
                            class_name="flex justify-between w-full px-4",
                        ),
                        class_name="p-6 bg-white border border-gray-200 rounded-xl shadow-sm",
                    ),
                ),
            ),

            class_name="bg-white p-8 rounded-2xl shadow-sm border border-gray-100",
        )
    )