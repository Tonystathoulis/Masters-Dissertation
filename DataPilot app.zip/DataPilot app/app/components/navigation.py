import reflex as rx 
from app.states.main_state import AppState  

#NAVIGATION COMPONENT RESPONSIBLE FOR STEP TRANSITIONS AND USER FLOW CONTROL
def step_nav() -> rx.Component:
    return rx.el.div(
        
        #BACK BUTTON FOR NAVIGATING TO PREVIOUS STEP
        rx.el.button(
            rx.icon("arrow-left", class_name="w-4 h-4 mr-2"),
            "Back",
            on_click=AppState.prev_step,  #TRIGGERS STATE UPDATE TO MOVE ONE STEP BACK
            disabled=(AppState.current_step == 0) | AppState.is_training,  #DISABLE AT FIRST STEP OR DURING TRAINING PROCESS
            class_name="flex items-center px-5 py-2.5 rounded-xl font-medium border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
        ),

        #DYNAMIC FORWARD BUTTON RENDERING BASED ON CURRENT STEP
        rx.match(
            AppState.current_step,

            #REQUIRE FILE UPLOAD BEFORE PROCEEDING
            (
                0,
                rx.el.button(
                    "Next",
                    rx.icon("arrow-right", class_name="w-4 h-4 ml-2"),
                    on_click=AppState.next_step,
                    disabled=AppState.filename == "",  #PREVENT PROGRESSION WITHOUT FILE INPUT
                    class_name="flex items-center px-5 py-2.5 rounded-xl font-medium bg-gray-900 text-white hover:bg-black shadow-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                ),
            ),

            #DATA PREVIEW (NO VALIDATION REQUIRED TO CONTINUE)
            (
                1,
                rx.el.button(
                    "Next",
                    rx.icon("arrow-right", class_name="w-4 h-4 ml-2"),
                    on_click=AppState.next_step,
                    class_name="flex items-center px-5 py-2.5 rounded-xl font-medium bg-gray-900 text-white hover:bg-black shadow-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                ),
            ),

            #REQUIRE TARGET VARIABLE SELECTION
            (
                2,
                rx.el.button(
                    "Continue to Training",
                    rx.icon("arrow-right", class_name="w-4 h-4 ml-2"),
                    on_click=AppState.next_step,
                    disabled=AppState.target_column == "",  #ENSURE TARGET VARIABLE IS SELECTED
                    class_name="flex items-center px-5 py-2.5 rounded-xl font-medium bg-gray-900 text-white hover:bg-black shadow-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                ),
            ),

            #WAIT FOR TRAINING COMPLETION BEFORE SHOWING RESULTS
            (
                3,
                rx.el.button(
                    "View Results",
                    rx.icon("arrow-right", class_name="w-4 h-4 ml-2"),
                    on_click=AppState.next_step,
                    disabled=AppState.training_progress < 100,  #BLOCK UNTIL TRAINING REACHES 100%
                    class_name="flex items-center px-5 py-2.5 rounded-xl font-medium bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                ),
            ),

            #FINAL STEP WITH OPTION TO RESET APPLICATION
            (
                4,
                rx.el.button(
                    "Start Over",
                    rx.icon("refresh-cw", class_name="w-4 h-4 ml-2"),
                    on_click=AppState.start_over,  #RESET ENTIRE PIPELINE TO INITIAL STATE
                    class_name="flex items-center px-5 py-2.5 rounded-xl font-medium bg-gray-900 text-white hover:bg-black shadow-sm transition-colors",
                ),
            ),

            #FALLBACK STATE (UNEXPECTED STEP INDEX)
            rx.el.button(
                "Done",
                rx.icon("check", class_name="w-4 h-4 ml-2"),
                disabled=True,
                class_name="flex items-center px-5 py-2.5 rounded-xl font-medium bg-gray-600 text-white shadow-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
            ),
        ),

        #LAYOUT CONTAINER FOR NAVIGATION BUTTONS
        class_name="flex justify-between items-center w-full max-w-4xl mx-auto mt-8 mb-12 px-4",
    )