import reflex as rx
from app.states.main_state import AppState

#COMPONENT RESPONSIBLE FOR RENDERING A SINGLE STEP IN THE STEPPER UI
def step_item(step: str, index: int) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            #CONDITIONAL RENDERING OF STEP CONTENT
            rx.cond(
                AppState.current_step > index,
                rx.icon("check", class_name="w-4 h-4 text-white"),  #DISPLAY CHECK ICON FOR COMPLETED STEPS
                rx.el.span(
                    f"{index + 1}",  #DISPLAY STEP INDEX FOR CURRENT AND FUTURE STEPS
                    class_name=rx.cond(
                        AppState.current_step == index,
                        "text-white",  #HIGHLIGHT CURRENT STEP
                        "text-gray-500",  #DIM FUTURE STEPS
                    ),
                ),
            ),
            #DYNAMIC STYLING BASED ON STEP STATE (COMPLETED, CURRENT, UPCOMING)
            class_name=rx.cond(
                AppState.current_step > index,
                "w-8 h-8 rounded-full flex items-center justify-center bg-emerald-500 transition-colors",
                rx.cond(
                    AppState.current_step == index,
                    "w-8 h-8 rounded-full flex items-center justify-center bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)] transition-colors",  #ADD GLOW EFFECT FOR CURRENT STEP
                    "w-8 h-8 rounded-full flex items-center justify-center bg-gray-200 transition-colors",
                ),
            ),
        ),
        #STEP LABEL DISPLAY WITH STATE-DEPENDENT STYLING
        rx.el.span(
            step,
            class_name=rx.cond(
                AppState.current_step >= index,
                "mt-2 text-sm font-semibold text-emerald-700",  #ACTIVE OR COMPLETED STEP
                "mt-2 text-sm font-medium text-gray-500",  #INACTIVE STEP
            ),
        ),
        class_name="flex flex-col items-center relative z-10",
    )

#MAIN STEPPER COMPONENT RESPONSIBLE FOR LAYOUT AND PROGRESS VISUALIZATION
def stepper() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            #BACKGROUND PROGRESS BAR (STATIC BASE LINE)
            rx.el.div(class_name="absolute top-4 left-0 w-full h-1 bg-gray-200 -z-0"),
            
            #DYNAMIC PROGRESS BAR INDICATING CURRENT STEP PROGRESSION
            rx.el.div(
                class_name="absolute top-4 left-0 h-1 bg-emerald-500 transition-all duration-300 -z-0",
                style={
                    "width": f"calc({AppState.current_step} * 25%)"
                },  #WIDTH SCALES BASED ON CURRENT STEP INDEX
            ),
            
            #RENDERING OF ALL STEP ITEMS USING ITERATION OVER STATE
            rx.el.div(
                rx.foreach(
                    AppState.steps,
                    lambda step, index: step_item(step, index)  #MAP EACH STEP TO A STEP ITEM COMPONENT
                ),
                class_name="flex justify-between items-center w-full",
            ),
            class_name="relative",
        ),
        class_name="w-full max-w-4xl mx-auto mb-10 px-4 pt-6",
    )