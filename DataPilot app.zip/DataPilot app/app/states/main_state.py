import reflex as rx  #REFLEX FRAMEWORK FOR STATE MANAGEMENT AND UI REACTIVITY
import pandas as pd  #DATA PROCESSING AND DATAFRAME OPERATIONS
import io  #HANDLE IN-MEMORY BYTE STREAMS FOR FILE PROCESSING
import base64  #ENCODE OF IMAGES FOR UI DISPLAY
import matplotlib  #PLOTTING BACKEND CONFIGURATION

#NON-INTERACTIVE BACKEND FOR SERVER-SIDE PLOTTING
matplotlib.use("Agg")

import matplotlib.pyplot as plt  #DATA VISUALIZATION
from sklearn.model_selection import train_test_split  #TRAIN/TEST SPLITTING
from sklearn.preprocessing import LabelEncoder  #ENCODE CATEGORICAL VARIABLES

#MODEL IMPORTS FOR AUTOMATED MODEL SELECTION
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge
from sklearn.ensemble import (
    RandomForestClassifier,
    RandomForestRegressor,
    GradientBoostingClassifier,
    GradientBoostingRegressor,)
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor

#MODEL EVALUATION METRICS
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    mean_squared_error,
    r2_score,
    confusion_matrix,
    ConfusionMatrixDisplay,)

import asyncio  #ASYNC SUPPORT FOR NON-BLOCKING TRAINING PIPELINE

#APPLICATION STATE: CENTRALIZED STATE MANAGEMENT FOR THE ENTIRE ML PIPELINE
class AppState(rx.State):

    #PIPELINE NAVIGATION STATE
    current_step: int = 0
    steps: list[str] = ["Upload", "Preview", "Configure", "Train", "Results"]

    #DATASET STORAGE AND METADATA
    filename: str = ""
    is_uploading: bool = False
    _df_bytes: bytes = b""  #RAW FILE STORAGE
    raw_data: list[dict[str, str]] = []
    columns: list[str] = []
    column_info: list[dict[str, str]] = []
    numeric_stats: list[dict[str, str]] = []
    dataset_shape: str = ""

    #TARGET CONFIGURATION
    target_column: str = ""
    task_type: str = ""  #CLASSIFICATION OR REGRESSION
    target_stats: dict[str, str] = {}

    #TRAINING CONFIGURATION
    test_size: int = 20

    #TRAINING STATE TRACKING
    is_training: bool = False
    training_progress: int = 0
    training_status_msg: str = ""

    #MODEL OUTPUTS AND RESULTS STORAGE
    model_results: list[dict[str, str]] = []
    best_model_name: str = ""
    best_model_score: str = ""

    #VISUALIZATION OUTPUTS (ENCODED IMAGES)
    feature_importance_plot: str = ""
    model_comparison_plot: str = ""
    confusion_matrix_plots: list[dict[str, str]] = []
    pred_vs_actual_plots: list[dict[str, str]] = []
    correlation_heatmap: str = ""

    #DATA VALIDATION FLAG
    show_data_validity_warning: bool = False

    #FILE UPLOAD HANDLER: READS CSV AND EXTRACTS PREVIEW + METADATA
    @rx.event
    async def handle_upload(self, files: list[rx.UploadFile]):

        #VALIDATION: ENSURE FILE EXISTS
        if not files:
            return

        self.is_uploading = True
        yield  #TRIGGER UI UPDATE

        try:
            file = files[0]
            data = await file.read()

            #STORE RAW FILE FOR LATER TRAINING
            self._df_bytes = data

            #LOAD DATAFRAME FROM MEMORY
            df = pd.read_csv(io.BytesIO(data))

            #BASIC DATASET METADATA
            self.filename = file.name
            self.dataset_shape = f"{df.shape[0]} rows × {df.shape[1]} columns"
            self.columns = df.columns.tolist()

            #DATA PREVIEW (FIRST 10 ROWS)
            preview_df = df.head(10).fillna("")
            self.raw_data = preview_df.astype(str).to_dict("records")

            #COLUMN INFORMATION EXTRACTION
            col_info = []
            for col in df.columns:
                col_info.append(
                    {
                        "name": col,
                        "dtype": str(df[col].dtype),
                        "non_null": str(df[col].count()),
                        "unique": str(df[col].nunique()),
                    }
                )
            self.column_info = col_info

            #NUMERIC STATISTICS COMPUTATION
            num_df = df.select_dtypes(include=["number"])
            num_stats = []

            if not num_df.empty:
                desc = num_df.describe().T

                for col in desc.index:
                    num_stats.append(
                        {
                            "name": col,
                            "mean": f"{desc.loc[col, 'mean']:.4f}",
                            "std": f"{desc.loc[col, 'std']:.4f}",
                            "min": f"{desc.loc[col, 'min']:.4f}",
                            "max": f"{desc.loc[col, 'max']:.4f}",
                        }
                    )

            self.numeric_stats = num_stats

            #MOVE TO NEXT STEP (PREVIEW)
            self.current_step = 1

        except Exception as e:
            import logging
            logging.exception(f"Error: {e}")

            #USER-FACING ERROR MESSAGE
            yield rx.toast.error(f"Error parsing CSV: {str(e)}")

        finally:
            self.is_uploading = False

    #TARGET COLUMN SELECTION AND TASK TYPE INFERENCE
    @rx.event
    def set_target_column(self, col: str):

        self.target_column = col

        #DETERMINE TASK TYPE BASED ON DATA CHARACTERISTICS
        if col and col in self.columns:

            info = next(
                (item for item in self.column_info if item["name"] == col), None
            )

            if info:
                unique_vals = int(info["unique"])
                dtype = info["dtype"]

                #HEURISTIC: SMALL UNIQUE VALUES OR CATEGORICAL CLASSIFICATION
                if dtype == "object" or dtype == "bool" or unique_vals < 20:
                    self.task_type = "Classification"
                else:
                    self.task_type = "Regression"

                self.target_stats = info

    #SET TRAIN/TEST SPLIT RATIO FROM UI INPUT
    @rx.event
    def set_test_size(self, size: str):
        self.test_size = int(size)

    #PIPELINE NAVIGATION: MOVE FORWARD
    @rx.event
    def next_step(self):
        if self.current_step < len(self.steps) - 1:
            self.current_step += 1

    #PIPELINE NAVIGATION: MOVE BACKWARD
    @rx.event
    def prev_step(self):
        if self.current_step > 0:
            self.current_step -= 1

    #RESET APPLICATION STATE TO INITIAL VALUES
    @rx.event
    def start_over(self):

        #RESET ALL PIPELINE STATE VARIABLES
        self.current_step = 0
        self.filename = ""
        self._df_bytes = b""
        self.raw_data = []
        self.columns = []
        self.column_info = []
        self.numeric_stats = []
        self.dataset_shape = ""
        self.target_column = ""
        self.task_type = ""
        self.target_stats = {}
        self.test_size = 20

        #RESET TRAINING STATE
        self.is_training = False
        self.training_progress = 0
        self.training_status_msg = ""

        #CLEAR MODEL OUTPUTS
        self.model_results = []
        self.best_model_name = ""
        self.best_model_score = ""
        self.feature_importance_plot = ""
        self.model_comparison_plot = ""
        self.confusion_matrix_plots = []
        self.pred_vs_actual_plots = []
        self.correlation_heatmap = ""
        self.show_data_validity_warning = False

    #MODEL TRAINING PIPELINE (RUNS IN BACKGROUND)
    @rx.event(background=True)
    async def train_models(self):

        #INITIALIZE TRAINING STATE
        async with self:
            self.is_training = True
            self.training_progress = 0
            self.training_status_msg = "Preprocessing data..."

            #CLEAR PREVIOUS RESULTS
            self.model_results = []
            self.feature_importance_plot = ""
            self.model_comparison_plot = ""
            self.confusion_matrix_plots = []
            self.pred_vs_actual_plots = []
            self.correlation_heatmap = ""
            self.best_model_name = ""
            self.best_model_score = ""
            self.show_data_validity_warning = False

        await asyncio.sleep(0.5)

        try:
            #LOAD DATA FROM STORED BYTES
            df = pd.read_csv(io.BytesIO(self._df_bytes))

            #REMOVE COLUMNS WITH TOO MANY MISSING VALUES
            limit = len(df) * 0.5
            cols_to_keep = df.columns[df.isnull().sum() <= limit]

            #ENSURE TARGET COLUMN IS NOT DROPPED
            if self.target_column not in cols_to_keep:
                cols_to_keep = cols_to_keep.append(pd.Index([self.target_column]))

            df = df[cols_to_keep].copy()

            #MISSING VALUE HANDLING (NUMERIC → MEDIAN, CATEGORICAL → MODE)
            for col in df.columns:
                if df[col].isnull().any():
                    if pd.api.types.is_numeric_dtype(df[col]):
                        df[col] = df[col].fillna(df[col].median())
                    else:
                        mode_val = df[col].mode()
                        df[col] = df[col].fillna(
                            mode_val[0] if not mode_val.empty else "Unknown"
                        )

            #ENCODE CATEGORICAL VARIABLES USING LABEL ENCODER
            le_dict = {}
            for col in df.columns:
                if not pd.api.types.is_numeric_dtype(df[col]):
                    le = LabelEncoder()
                    df[col] = le.fit_transform(df[col].astype(str))
                    le_dict[col] = le

            #FEATURE/TARGET SPLIT
            X = df.drop(columns=[self.target_column])
            y = df[self.target_column]

            #TRAIN/TEST SPLIT
            X_train, X_test, y_train, y_test = train_test_split(
                X, y,
                test_size=self.test_size / 100.0,
                random_state=42
            )
                       #MODEL SELECTION BASED ON TASK TYPE
            if self.task_type == "Classification":
                models = {
                    "Logistic Regression": LogisticRegression(max_iter=1000),
                    "Random Forest": RandomForestClassifier(random_state=42),
                    "Gradient Boosting": GradientBoostingClassifier(random_state=42),
                    "Decision Tree": DecisionTreeClassifier(random_state=42),
                    "K-Nearest Neighbors": KNeighborsClassifier(),
                }

                #METRICS FOR CLASSIFICATION TASKS
                primary_metric_name = "Accuracy"
                secondary_metric_name = "F1 Score"

            else:
                models = {
                    "Linear Regression": LinearRegression(),
                    "Ridge Regression": Ridge(),
                    "Random Forest Regressor": RandomForestRegressor(random_state=42),
                    "Gradient Boosting Regressor": GradientBoostingRegressor(random_state=42),
                    "Decision Tree Regressor": DecisionTreeRegressor(random_state=42),
                }

                #METRICS FOR REGRESSION TASKS
                primary_metric_name = "R² Score"
                secondary_metric_name = "RMSE"

            #INITIALIZE RESULT TRACKING VARIABLES
            results = []
            total_models = len(models)
            best_model = None
            best_score = -float("inf")

            #PLOT STORAGE FOR UI VISUALIZATION
            cm_plots = []   
            pa_plots = []   

            #MODEL TRAINING LOOP (AUTO ML CORE)
            for i, (name, model) in enumerate(models.items()):

                #UPDATE TRAINING PROGRESS IN UI
                async with self:
                    self.training_status_msg = f"Training {name} ({i + 1}/{total_models})..."
                    self.training_progress = 10 + int(80 * (i / total_models))

                await asyncio.sleep(0.1)

                #MODEL TRAINING + PREDICTION
                model.fit(X_train, y_train)
                preds = model.predict(X_test)

                #EVALUATION LOGIC BASED ON TASK TYPE
                if self.task_type == "Classification":

                    #CLASSIFICATION METRICS
                    primary_score = accuracy_score(y_test, preds)
                    secondary_score = f1_score(y_test, preds, average="weighted")

                    #CONFUSION MATRIX GENERATION
                    cm = confusion_matrix(y_test, preds)
                    fig, ax = plt.subplots(figsize=(6, 5))

                    disp = ConfusionMatrixDisplay(
                        confusion_matrix=cm,
                        display_labels=model.classes_ if hasattr(model, "classes_") else None,
                    )

                    disp.plot(ax=ax, cmap="Blues", values_format="d")
                    plt.title(f"{name} Confusion Matrix")
                    plt.tight_layout()

                    #ENCODE PLOT TO BASE64 FOR UI DISPLAY
                    buf_cm = io.BytesIO()
                    plt.savefig(buf_cm, format="png", dpi=150)
                    buf_cm.seek(0)
                    cm_plot_b64 = base64.b64encode(buf_cm.read()).decode("utf-8")
                    plt.close()

                    cm_plots.append({
                        "name": name,
                        "plot": f"data:image/png;base64,{cm_plot_b64}"
                    })

                else:

                    #REGRESSION METRICS
                    primary_score = r2_score(y_test, preds)
                    secondary_score = mean_squared_error(y_test, preds) ** 0.5

                    #PREDICTED VS ACTUAL SCATTER PLOT
                    fig, ax = plt.subplots(figsize=(6, 5))
                    ax.scatter(y_test, preds, color="#4b5563", alpha=0.6)

                    #REFERENCE LINE (IDEAL PREDICTIONS)
                    min_val = min(y_test.min(), preds.min())
                    max_val = max(y_test.max(), preds.max())
                    ax.plot([min_val, max_val], [min_val, max_val], color="red", linestyle="--")

                    ax.set_xlabel("Actual")
                    ax.set_ylabel("Predicted")
                    ax.set_title(f"{name} Predicted vs Actual")
                    ax.grid(True, linestyle=":", alpha=0.6)

                    plt.tight_layout()

                    #ENCODE PLOT
                    buf_pa = io.BytesIO()
                    plt.savefig(buf_pa, format="png", dpi=150)
                    buf_pa.seek(0)
                    pa_plot_b64 = base64.b64encode(buf_pa.read()).decode("utf-8")
                    plt.close()

                    pa_plots.append({
                        "name": name,
                        "plot": f"data:image/png;base64,{pa_plot_b64}"
                    })

                #STORE MODEL RESULTS
                results.append({
                    "name": name,
                    "primary_metric": f"{primary_score:.4f}",
                    "secondary_metric": f"{secondary_score:.4f}",
                    "primary_score_raw": primary_score,
                })

                #TRACK BEST MODEL BASED ON PRIMARY METRIC
                if primary_score > best_score:
                    best_score = primary_score
                    best_model = model

                    async with self:
                        self.best_model_name = name
                        self.best_model_score = f"{primary_score:.4f} {primary_metric_name}"

            #FINAL PROCESSING STAGE
            async with self:
                self.training_status_msg = "Generating insights..."
                self.training_progress = 95

            await asyncio.sleep(0.1)

            #MODEL COMPARISON BAR CHART
            plt.figure(figsize=(10, 6))
            names = [r["name"] for r in results]
            scores = [r["primary_score_raw"] for r in results]

            plt.barh(names, scores, color="#1f2937")
            plt.xlabel(primary_metric_name)
            plt.title("Model Comparison")
            plt.tight_layout()

            buf = io.BytesIO()
            plt.savefig(buf, format="png")
            buf.seek(0)
            model_plot = base64.b64encode(buf.read()).decode("utf-8")
            plt.close()

            #FEATURE IMPORTANCE (ONLY FOR SUPPORTED MODELS)
            feat_plot = ""
            if hasattr(best_model, "feature_importances_"):

                importances = best_model.feature_importances_
                indices = importances.argsort()[::-1][:10]

                plt.figure(figsize=(10, 6))
                plt.bar(range(len(indices)), importances[indices], align="center", color="#1f2937")

                plt.xticks(
                    range(len(indices)),
                    [X.columns[i] for i in indices],
                    rotation=45,
                    ha="right",
                )

                plt.title("Top 10 Feature Importances")
                plt.tight_layout()

                buf2 = io.BytesIO()
                plt.savefig(buf2, format="png")
                buf2.seek(0)
                feat_plot = base64.b64encode(buf2.read()).decode("utf-8")
                plt.close()

            #CORRELATION HEATMAP GENERATION (NUMERIC FEATURES ONLY)
            df_orig = pd.read_csv(io.BytesIO(self._df_bytes))
            num_cols = df_orig.select_dtypes(include=["number"]).columns
            heatmap_b64 = ""

            if len(num_cols) > 1:
                corr = df_orig[num_cols].corr()

                fig, ax = plt.subplots(figsize=(10, 8))
                cax = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
                fig.colorbar(cax)

                ax.set_xticks(range(len(num_cols)))
                ax.set_yticks(range(len(num_cols)))
                ax.set_xticklabels(num_cols, rotation=45, ha="right")
                ax.set_yticklabels(num_cols)

                #ANNOTATE CORRELATION VALUES
                for idx_i in range(len(num_cols)):
                    for idx_j in range(len(num_cols)):
                        val = corr.iloc[idx_i, idx_j]
                        color = "white" if abs(val) > 0.5 else "black"

                        ax.text(idx_j, idx_i, f"{val:.2f}", ha="center", va="center", color=color, fontsize=9)

                plt.title("Correlation Heatmap")
                plt.tight_layout()

                buf_hm = io.BytesIO()
                plt.savefig(buf_hm, format="png", dpi=150)
                buf_hm.seek(0)
                heatmap_b64 = base64.b64encode(buf_hm.read()).decode("utf-8")
                plt.close()

            #DATA VALIDITY CHECK (DETECT SUSPICIOUSLY HIGH PERFORMANCE)
            async with self:

                perfect_count = 0

                for r in results:
                    p_score = r["primary_score_raw"]

                    if self.task_type == "Classification":
                        #DATA VALIDITY WARNING TRIGGERED IF MORE THAN ONE MODEL ACHIEVES A SCORE OF 0.98 OR HIGHER
                        if p_score >= 0.98:
                            perfect_count += 1
                    else:
                        s_score = float(r["secondary_metric"])
                        #FOR REGRESSION, WARNING IF PRIMARY SCORE >= 0.98 OR SECONDARY METRIC IS EXTREMELY LOW
                        if p_score >= 0.98 or s_score < 0.0001:
                            perfect_count += 1

                if perfect_count > 1:
                    self.show_data_validity_warning = True

                #FINAL RESULTS SORTING AND CLEANUP
                results.sort(key=lambda x: x["primary_score_raw"], reverse=True)

                for r in results:
                    del r["primary_score_raw"]

                #STORE FINAL RESULTS IN STATE
                self.model_results = results
                self.model_comparison_plot = f"data:image/png;base64,{model_plot}"

                if feat_plot:
                    self.feature_importance_plot = f"data:image/png;base64,{feat_plot}"

                self.confusion_matrix_plots = cm_plots
                self.pred_vs_actual_plots = pa_plots

                if heatmap_b64:
                    self.correlation_heatmap = f"data:image/png;base64,{heatmap_b64}"

                #FINAL TRAINING STATE UPDATE
                self.training_progress = 100
                self.training_status_msg = "Training Complete!"
                self.is_training = False

        #ERROR HANDLING FOR TRAINING PIPELINE
        except Exception as e:
            import logging
            logging.exception(f"Training error: {e}")

            async with self:
                self.is_training = False
                self.training_status_msg = f"Error: {str(e)}"