import reflex as rx  #REFLEX FRAMEWORK FOR STATE MANAGEMENT AND UI REACTIVITY
from app.states.main_state import AppState  #APPLICATION STATE MANAGEMENT IMPORT
from app.components.stepper import stepper  #UI COMPONENT IMPORTS FOR PIPELINE STRUCTURE

#DATA PROCESSING STEP COMPONENTS
from app.components.data_steps import (
    upload_step,   #HANDLES DATA UPLOAD INTERFACE AND FILE INPUT
    preview_step,  #DISPLAYS DATA PREVIEW FOR USER VALIDATION
    target_step)    #ALLOWS USER TO SELECT TARGET VARIABLE FOR MODELING

#MODEL TRAINING AND RESULTS COMPONENTS
from app.components.model_steps import (
    train_step,    
    results_step)  

#NAVIGATION COMPONENT FOR STEP NAVIGATION
from app.components.navigation import step_nav 

#MAIN USER INTERFACE ENTRY POINT AND PIPELINE ORCHESTRATION
def index() -> rx.Component:
    return rx.el.div(
        
        #APPLICATION HEADER WITH TITLE AND RESET FUNCTIONALITY
        rx.el.header(
            rx.el.div(
                rx.icon("chart-spline", class_name="w-8 h-8 text-gray-900 mr-3"),
                rx.el.h1(
                    "DataPilot",
                    on_click=AppState.start_over,  #RESETS APPLICATION STATE TO INITIAL STEP
                    class_name="text-4xl font-bold text-gray-900 tracking-tight cursor-pointer",
                ),
                class_name="flex items-center",
            ),
            class_name="w-full bg-white border-b border-gray-200 px-8 py-4 shadow-sm",
        ),

        #MAIN CONTENT AREA CONTAINING STEPPER, DYNAMIC STEP CONTENT, AND NAVIGATION
        rx.el.main(
            
            #STEPPER COMPONENT SHOWING CURRENT PROGRESS
            stepper(),

            #DYNAMIC RENDERING OF STEP CONTENT BASED ON CURRENT STATE
            rx.el.div(
                rx.match(
                    AppState.current_step,  #SWITCH-LIKE CONTROL FLOW BASED ON CURRENT STEP INDEX
                    (0, upload_step()),   
                    (1, preview_step()),  
                    (2, target_step()),   
                    (3, train_step()),    
                    (4, results_step()),  
                    
                    #FALLBACK UI FOR INVALID STATE VALUES
                    rx.el.div(
                        "Error: Step not found",
                        class_name="p-12 text-center text-red-500 bg-white rounded-2xl border border-gray-100 shadow-sm",
                    ),
                ),
                class_name="w-full max-w-4xl mx-auto px-4",
            ),

            #CONDITIONAL RENDERING OF NAVIGATION (HIDDEN ON FINAL STEP)
            rx.cond(
                AppState.current_step < 4,
                step_nav(),  #ENABLE STEP NAVIGATION UNTIL FINAL RESULTS STEP
                None
            ),

            class_name="flex-1 overflow-y-auto bg-gray-50 pb-12",
        ),

        class_name="font-['Inter'] min-h-screen flex flex-col bg-gray-50",
    )

#APPLICATION INITIALIZATION AND GLOBAL CONFIGURATION
app = rx.App(
    theme=rx.theme(appearance="light"),  #SET GLOBAL UI THEME (LIGHT MODE)
    
    #EXTERNAL FONT CONFIGURATION
    head_components=[
        rx.el.link(rel="preconnect", href="https://fonts.googleapis.com"),
        rx.el.link(rel="preconnect", href="https://fonts.gstatic.com", cross_origin=""),
        rx.el.link(
            href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap",
            rel="stylesheet",
        ),
    ],
)

#REGISTER MAIN PAGE ROUTE WITH THE APPLICATION
app.add_page(index, route="/")  