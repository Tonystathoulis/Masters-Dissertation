@echo off
REM Install all required Python packages for the Auto ML App
pip install -r requirements.txt
